package com.example.signupaactivity;

public interface ConnectivityChangeListener {
    void onConnectivityChange(boolean isConnected);
}