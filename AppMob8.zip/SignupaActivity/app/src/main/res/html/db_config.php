<?php
define('HOST','localhost');
define('USER','bmo');
define('PASS','0000');
define('DB','android_db');
$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
?>
